import numpy as np
import torch
from pkg_resources import packaging

print("Torch version:", torch.__version__)

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Apr 23 19:52:20 2022

@author: meta research
Slightly modified by our project group
demo
"""

from PIL import Image
import torchvision.transforms as T
from src.flexit_editer import FlexitEditer
import ipywidgets as widgets
from io import BytesIO
import os

torch.set_grad_enabled(True);

transformer = FlexitEditer(
    names = ['RN50', 'RN50x4', 'ViT-B/32', 'RN50x16', 'ViT-B/16'],
    img_size = 288,
    mode = 'vqgan',
    lr=0.05,
    #device = 'cuda:0',
    device = 'cpu',
    n_augment = 1,
    znorm_weight = 0.05,
    im0_coef = 0.2,
    source_coef=0.4,
    latent_space = 'vqgan',
    lpips_weight = 0.15,
)

def translate(img_path = None, pil_img = None, S = None, T = None, save_dir = ""):
    filename = os.path.basename(img_path)
    if pil_img is None:
        img0 = Image.open(img_path).convert('RGB')
    else:
        img0 = pil_img.convert('RGB')
    
    bio = BytesIO()
    img0.save(bio, format='png')
    
    im = widgets.Image(
                value=bio.getvalue(),
                format='png',
                width=384,
                height=384)
    # display(im)
    
    transformer.args.max_iter = 2
    out_imgs, *_ = transformer(img0, S, T)
    out_img = out_imgs[transformer.args.max_iter]
    bio = BytesIO()
    out_img.save(bio, format='png')
    out_img.save(save_dir+"/"+filename)
    im.value = bio.getvalue()
    return out_img
    
    
    